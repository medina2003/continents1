package com.example.continents;

public interface OnClickListener {
    void onClick (String  name);
}
